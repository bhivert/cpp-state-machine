/*
* enum.h
* Copyright (C) 2019 Benoit Hivert <hivert.benoit@gmail.com>
*
* Created on 2019/04/25 at 22:28:14 by Benoit Hivert <hivert.benoit@gmail.com>
* Updated on 2019/04/25 at 22:36:17 by Benoit Hivert <hivert.benoit@gmail.com>
*/

#ifndef ENUM_H
# define ENUM_H

/*!
  @file enum.h
  @brief ...
  */

typedef enum class _test0 {
	_0 = 0,
	_1,
	_2
} test0;

typedef enum class _test1 {
	_0 = 1,
	_1,
	_2
} test1;

#endif
