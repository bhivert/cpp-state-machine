/*
* main.cpp
* Copyright (C) 2019 Benoit Hivert <hivert.benoit@gmail.com>
*
* Created on 2019/04/25 at 22:14:14 by Benoit Hivert <hivert.benoit@gmail.com>
* Updated on 2019/04/25 at 22:39:24 by Benoit Hivert <hivert.benoit@gmail.com>
*/

/*!
  @file main.cpp
  @brief ...
  */

#include "enum.h"
#include "toto.h"

int main () {
	toto< test0 >	t0;
	toto< test1 >	t1;
	return 0;
}
