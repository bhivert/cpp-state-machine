/*
* toto.h
* Copyright (C) 2019 Benoit Hivert <hivert.benoit@gmail.com>
*
* Created on 2019/04/25 at 22:29:58 by Benoit Hivert <hivert.benoit@gmail.com>
* Updated on 2019/04/25 at 22:40:01 by Benoit Hivert <hivert.benoit@gmail.com>
*/

#ifndef TOTO_H
# define TOTO_H

/*!
  @file toto.h
  @brief ...
  */

#include <iostream>
#include <string>

template < typename T >
class toto {
	public:
		toto() {
			std::cout << std::to_string((int)T::_0) << std::endl;
		}
};

#endif
